import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-titlr',
  templateUrl: './titlr.component.html',
  styleUrls: ['./titlr.component.css']
})
export class TitlrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
