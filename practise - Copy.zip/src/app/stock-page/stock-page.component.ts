import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stock-page',
  templateUrl: './stock-page.component.html',
  styleUrls: ['./stock-page.component.css']
})
export class StockPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
