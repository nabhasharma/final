export class Product{
    id:string;
    name:string;
    price:any;
    description:string;
    action:string;
    quantity:number;
    stock:number;
    stockss:string;
}